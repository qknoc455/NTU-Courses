module alu #(
    parameter INST_W = 4,
    parameter INT_W  = 6,
    parameter FRAC_W = 10,
    parameter DATA_W = INT_W + FRAC_W
)(
    input                      i_clk,
    input                      i_rst_n,

    input                      i_in_valid,
    output                     o_busy,
    input         [INST_W-1:0] i_inst,
    input  signed [DATA_W-1:0] i_data_a,
    input  signed [DATA_W-1:0] i_data_b,

    output                     o_out_valid,
    output        [DATA_W-1:0] o_data
);

    // Local Parameters
    parameter IDLE = 2'b00 ;      // 空閒狀態
    parameter BUSY = 2'b01 ;      // 處理數據中
    parameter OUTPUT = 2'b10 ;      // 輸出

    parameter Addition = 4'b0000 ;
    parameter Subtraction = 4'b0001 ;
    parameter Multiplication  = 4'b0010 ;
    parameter Accumulation  = 4'b0011 ;
    parameter Softplus  = 4'b0100 ;
    parameter XOR = 4'b0101 ;
    parameter Right_Shift = 4'b0110 ;
    parameter Left_Rotation  = 4'b0111 ;
    parameter Count_Leading_Zeros = 4'b1000 ;
    parameter Reverse_Match4 = 4'b1001 ;
    


    // Wires and 
    reg [1:0] current_state;
    reg [1:0] next_state;
    reg signed [DATA_W-1:0] alu_result;
    reg o_busy_r;
    reg o_out_valid_r;
    reg [DATA_W-1:0] o_data_r;
    reg [DATA_W-1:0] i_data_a_reg;
    reg [DATA_W-1:0] i_data_b_reg;
    reg [INST_W-1:0] i_inst_reg;
    reg signed [19:0] data_acc [15:0];

    wire [3:0] index;

    // Continuous Assignments

    assign o_busy = o_busy_r;
    assign o_out_valid = o_out_valid_r;
    assign o_data = o_data_r;
    assign index = (current_state == IDLE)?(i_data_a[3:0]):(i_data_a_reg[3:0]);

    integer i;

    // Sequential Blocks
    always @(posedge i_clk or negedge i_rst_n) begin
        if (!i_rst_n)begin
            i_data_a_reg <= 16'd0;
            i_data_b_reg <= 16'd0;
            i_inst_reg <= 4'd0;
        end
        else if(i_in_valid)begin
            i_data_a_reg <= i_data_a;
            i_data_b_reg <= i_data_b;
            i_inst_reg <= i_inst;
        end
    end

    wire signed [19:0] acc_tmp;
    assign acc_tmp = data_acc[index] + i_data_b;
    always @(posedge i_clk or negedge i_rst_n) begin
        if (!i_rst_n)begin
            for(i=0;i<16;i=i+1)begin
                data_acc[i] <= 20'd0;
            end
        end
        else if(current_state == IDLE && i_in_valid && i_inst == Accumulation)begin
            data_acc[index] <= acc_tmp;
        end
    end


    always @(posedge i_clk or negedge i_rst_n) begin
        if (!i_rst_n)
            current_state <= IDLE;  // 當復位時，進入空閒狀態
        else
            current_state <= next_state;  // 否則進入下一狀態
    end
    // Combinatorial Blocks FSM_STATE
    always @(*) begin
        case (current_state)
            IDLE: begin
                if (i_in_valid)  // 當輸入有效時，轉移到 BUSY 狀態
                    next_state = BUSY;
                else
                    next_state = IDLE;
            end
            BUSY: begin
                // 模擬 ALU 操作，這裡使用一個時鐘周期完成操作
                next_state = OUTPUT;  // 操作完成後，轉移到 OUTPUT 狀態
            end
            OUTPUT: begin
                next_state = IDLE;  // 完成輸出後回到空閒狀態
            end
            default: next_state = IDLE;
        endcase
    end

    // Sequential Blocks FSM_OUTPUT
        always @(posedge i_clk or negedge i_rst_n) begin
        if (!i_rst_n) begin
            o_busy_r <= 1'b1;
            o_out_valid_r <= 1'b0;
            o_data_r <= 16'b0;
            alu_result <= 16'b0;
        end else begin
            case (current_state)
                IDLE: begin
                    if (i_in_valid)
                        o_busy_r <= 1'b1;  // 在空閒狀態下，ALU 準備接收新數據
                    else
                        o_busy_r <= 1'b0;
                    o_out_valid_r <= 1'b0;  // 沒有輸出數據
                end
                BUSY: begin
                    o_busy_r <= 1'b1;  // 在忙碌狀態，ALU 處理數據，阻止進一步輸入
                    o_out_valid_r <= 1'b0;
                    // 模擬 ALU 的運算操作
                    case(i_inst_reg) 
                        Addition: alu_result <= add_sub(i_data_a_reg,i_data_b_reg, 1'b0);
                        Subtraction: alu_result <= add_sub(i_data_a_reg,i_data_b_reg, 1'b1);
                        Multiplication: alu_result <= mul_16Q10(i_data_a_reg,i_data_b_reg);
                        Accumulation:begin
                            if( data_acc[index] > 16'sb0111_1111_1111_1111 )
                                alu_result <= 16'b0111_1111_1111_1111;
                            else if(data_acc[index] < 16'sb1000000000000000)
                                alu_result <= 16'b1000000000000000;
                            else
                                alu_result <= data_acc[index][15:0];
                        end
                        //alu_result <= ac(i_data_a_reg, i_data_b_reg);
                        Softplus: alu_result <= sp(i_data_a_reg);
                        XOR: alu_result <= x_or(i_data_a_reg,i_data_b_reg);
                        Right_Shift: alu_result <= rs(i_data_a_reg,i_data_b_reg);
                        Left_Rotation: alu_result <= lr(i_data_a_reg,i_data_b_reg);
                        Count_Leading_Zeros: alu_result <= clz(i_data_a_reg);
                        Reverse_Match4: alu_result <= rm4(i_data_a_reg,i_data_b_reg);
                    endcase
                end
                OUTPUT: begin
                    o_busy_r <= 1'b1;  // ALU 不再忙碌，可以接收下一輸入
                    o_out_valid_r <= 1'b1;  // 輸出有效信號
                    o_data_r <= alu_result;  // 將計算結果輸出
                end
                default: begin
                    o_busy_r <= 1'b0;
                    o_out_valid_r <= 1'b0;
                    o_data_r <= 16'b0;
                end
            endcase
        end
    end
//--------------------Addition--------------------//
    function automatic signed [DATA_W-1:0] add_sub;
    input signed [DATA_W-1:0] i_data_a;
    input signed [DATA_W-1:0] i_data_b;
    input mode;
    reg   signed [DATA_W:0] add_tmp;
    begin
        if (mode == 1'b0)
            add_tmp = i_data_a + i_data_b;
        else
            add_tmp = i_data_a - i_data_b;
        
        case ({add_tmp[DATA_W], add_tmp[DATA_W-1]})
        2'b00: add_sub = add_tmp [DATA_W-1:0];
        2'b01: add_sub = 16'b0111111111111111;
        2'b10: add_sub = 16'b1000000000000000;
        2'b11: add_sub = add_tmp [DATA_W-1:0];
        endcase
    end   
    endfunction

//--------------------Multiplication-------------------//
    function automatic signed [DATA_W-1:0] mul_16Q10;
    input signed [DATA_W-1:0] i_data_a;
    input signed [DATA_W-1:0] i_data_b;
    reg   signed [2*DATA_W-1:0] mul_32Q20;   //[31:0] mul_32Q20;
    reg   signed [2*DATA_W-10:0] mul_23Q10;  //[22:0] mul_23Q10;
    reg carry_bit ;
    begin
        mul_32Q20 = i_data_a * i_data_b;
        carry_bit = mul_32Q20[9];//mul_32Q20[31] ? ( mul_32Q20[9] & (|mul_32Q20[8:0]) ) : mul_32Q20[9];
        mul_23Q10 = {mul_32Q20[31],mul_32Q20[31:10]} + carry_bit;
        mul_16Q10 = (mul_23Q10[22:15] == 8'b0000_0000 || mul_23Q10[22:15] == 8'b1111_1111) ?
            mul_23Q10[15:0] : {mul_23Q10[22], {15{!mul_23Q10[22]}}};

    end   
    endfunction

    // (6_10)*(6_10) -> result =  (6_6_10_10) [9:0] -32.0000~31.99999 -32~31
    // result2 = result >> 10 (6_6_10) 
//-------------------- Accumulation--------------------//
/*
    function signed [15:0] ac;
    input signed [15:0] i_data_a;            // 4位索引，保证在0到15之间
    input signed [15:0] i_data_b;           // 20位有符号的累加值
    reg signed [19:0] data_acc [0:15];      // 16个存储单元，每个单元20位
    reg signed [3:0] index;                 // 4位索引
    reg signed [19:0] accumulated_value;    // 临时存储结果
    begin
        index = i_data_a;                   // 将索引设置为输入的索引值
        
        // 进行累加
        accumulated_value = data_acc[index] + i_data_b;
        
        // 饱和逻辑：如果累加值超过20位有符号数的范围
        if (accumulated_value > 20'sd524287) begin
            data_acc[index] = 20'sd524287;  // 20位有符号数的最大值
        end else if (accumulated_value < -20'sd524288) begin
            data_acc[index] = -20'sd524288;  // 20位有符号数的最小值
        end else begin
            data_acc[index] = accumulated_value;  // 值在范围内
        end
        
        // 将累加结果截断为16位输出
        ac = data_acc[index][15:0];
    end
    endfunction
    */
    
//--------------------Softplus-------------------//
    function automatic signed [DATA_W-1:0] sp;
    input signed [DATA_W-1:0] i_data_a;
    reg signed [DATA_W-1+20:0] i_data_a_tmp;//(16+2)+(16+2)-16 = 20
    reg signed [DATA_W-1:0] tmp;
    reg carry;
    begin
        /*
        if(i_data_a <= -6'sd3)
        sp = 16'b0000_0000_0000_0000;//
        else if((i_data_a >= -16'sb000011_0000000000) && (i_data_a <= -16'sb000010_0000000000))sp = ((i_data_a + $signed({6'd3, 10'd0})) * 16'sd7282) >>> 16;
        else if((i_data_a >= -16'sb000010_0000000000) && (i_data_a <= -16'sb000001_0000000000))sp = ((i_data_a + i_data_a  + $signed({6'd5, 10'd0})) * 16'sd7282) >>> 16;
        else if((i_data_a >= -16'sb000001_0000000000) && (i_data_a <=  16'sb000000_0000000000))sp = ((i_data_a + $signed({6'd2, 10'd0})) * 16'sd21845) >>> 16;
        else if((i_data_a >=  16'sb000000_0000000000) && (i_data_a <=  16'sb000010_0000000000))sp = ((i_data_a + i_data_a + $signed({6'd2, 10'd0})) * 16'sd21845) >>> 16;
        else if(i_data_a >= 16'sb000010_0000000000)
        sp = i_data_a;
        */
        
        i_data_a_tmp = {{20{i_data_a[15]}},i_data_a};
        if(i_data_a_tmp <= -16'sb000011_0000000000)
            sp = 16'b0000_0000_0000_0000;//
        else if((i_data_a_tmp >= -16'sb000011_0000000000) && (i_data_a_tmp <= -16'sb000010_0000000000))begin
            tmp = ((i_data_a_tmp + $signed({6'd3, 10'd0})) * 16'sd7282) >>> 15;
            carry = tmp[0];
            sp = (tmp + carry) >> 1;
        end
        else if((i_data_a_tmp >= -16'sb000010_0000000000) && (i_data_a_tmp <= -16'sb000001_0000000000))begin
            tmp = ((i_data_a_tmp + i_data_a_tmp  + $signed({6'd5, 10'd0})) * 16'sd7282) >>> 15;
            carry = tmp[0];
            sp = (tmp + carry) >> 1;
        end
        else if((i_data_a_tmp >= -16'sb000001_0000000000) && (i_data_a_tmp <=  16'sb000000_0000000000))begin
            tmp = ((i_data_a_tmp + $signed({6'd2, 10'd0})) * 16'sd21845) >>> 15;
            carry = tmp[0];
            sp = (tmp + carry) >> 1;
        end
        else if((i_data_a_tmp >=  16'sb000000_0000000000) && (i_data_a_tmp <=  16'sb000010_0000000000))begin
            tmp = ((i_data_a_tmp + i_data_a + $signed({6'd2, 10'd0})) * 16'sd21845) >>> 15;
            carry = tmp[0];
            sp = (tmp + carry) >> 1;
        end
        else if(i_data_a_tmp >= 16'sb000010_0000000000)
            sp = i_data_a_tmp[15:0];
        else
            sp = i_data_a_tmp[15:0];
        
    end   
    endfunction

//--------------------XOR-------------------//
    function automatic [DATA_W-1:0] x_or;
    input  [DATA_W-1:0] i_data_a;
    input  [DATA_W-1:0] i_data_b;
    begin
        x_or = i_data_a ^ i_data_b ;
    end   
    endfunction

//--------------------Right_Shift-------------------//
    function automatic [DATA_W-1:0] rs;
    input signed [DATA_W-1:0] i_data_a;
    input  [DATA_W-1:0] i_data_b;
    begin
        rs = i_data_a >>> i_data_b[4:0];
    end   
    endfunction

//--------------------Left_Rotation-------------------//
    function automatic [DATA_W-1:0] lr;
    input [DATA_W-1:0] i_data_a;
    input [DATA_W-1:0] i_data_b;
    reg [4:0]shift_amount;
    begin
        shift_amount = i_data_b[4:0]; // Store the shift amount in an integer
        lr = (i_data_a << shift_amount) | (i_data_a >> (DATA_W - shift_amount));
         // Use shift_amount instead of non-constant expression
    end
    endfunction

//--------------------Count_Leading_Zeros--------------------//
    function automatic integer clz;  // Specify the return type as integer
    input [DATA_W-1:0] i_data_a;  // Input data
    integer i;
    reg flap  ;
    begin
        clz = 0;  // Initialize clz to 0
        flap = 0;
        clz_loop: for (i = DATA_W-1; i >= 0; i = i - 1) begin
            if (i_data_a[i] == 1'b1) begin
                flap = 1;  // Exit the loop once the first '1' is found
            end
            else if(!flap)
            clz = clz + 1;  // Increment the count for each leading zero
           
        end
    end
    endfunction

//--------------------Reverse_Match4--------------------//
    function automatic [DATA_W-1:0] rm4;
    input [DATA_W-1:0] i_data_a;
    input [DATA_W-1:0] i_data_b;
    integer i;
    begin
        rm4[15:13] = 3'b000;
        for (i = 0; i <= 12; i = i + 1) begin
            if (i_data_a[i+3] == i_data_b[15-i] && i_data_a[i+2] == i_data_b[14-i] &&
                     i_data_a[i+1] == i_data_b[13-i] && i_data_a[i] == i_data_b[12-i])
                    rm4[i] = 1'b1;
             else
                     rm4[i] = 1'b0;
        end
    end
    endfunction

endmodule

   /* // Combinatorial Blocks

    always(*) begin
        case(i_inst)
        Addition: alu_result = add_sub(i_data_a,i_data_b);
        Subtraction: alu_result = add_sub(i_data_a,i_data_b);
        Multiplication: alu_result = mul_16Q10(i_data_a,i_data_b);

        Accumulation: 

        Softplus: alu_result = sp(i_data_a);
        XOR: alu_result = x_o r(i_data_a,i_data_b);
        Right_Shift: alu_result = rs(i_data_a,i_data_b);
        Left_Rotation: alu_result = lr(i_data_a,i_data_b);
        Count_Leading_Zeros: alu_result = clz(i_data_a);
        Reverse_Match4: alu_result = rm4(i_data_a,i_data_b);
        endcase
    end*/
