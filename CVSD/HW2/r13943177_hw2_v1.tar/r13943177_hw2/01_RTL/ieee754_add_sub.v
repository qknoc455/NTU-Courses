module ieee754_add_sub(
    input [31:0] a,        // 输入浮点数A
    input [31:0] b,        // 输入浮点数B
    input add_sub,         // 加法（1）或减法（0）选择信号
    output [31:0] result   // 输出结果
);
    // 提取符号位、指数位和尾数位
    wire sign_a = a[31];
    wire sign_b = b[31] ^ (!add_sub);  // 如果是减法，反转符号位
    wire [7:0] exp_a = a[30:23];
    wire [7:0] exp_b = b[30:23];
    wire [23+5:0] mant_a = {1'b1, a[22:0], 5'd0};  // 加入隐含1
    wire [23+5:0] mant_b = {1'b1, b[22:0], 5'd0};  // 加入隐含1

    // 对齐指数
    wire [7:0] exp_diff = (exp_a >= exp_b) ? (exp_a - exp_b) : (exp_b - exp_a);
    wire [23+5:0] mant_a_shifted = (exp_a >= exp_b) ? mant_a : (mant_a >> exp_diff);
    wire [23+5:0] mant_b_shifted = (exp_a >= exp_b) ? (mant_b >> exp_diff) : mant_b;
    wire [7:0] exp_result = (exp_a >= exp_b) ? exp_a : exp_b;

    // 处理尾数加法/减法
    wire [24+5:0] mant_sum;
    assign mant_sum = (sign_a == sign_b) ?
                        (mant_a_shifted + mant_b_shifted) :  // 同符号直接相加
                        (mant_a_shifted > mant_b_shifted) ? 
                            (mant_a_shifted - mant_b_shifted) : 
                            (mant_b_shifted - mant_a_shifted);  // 异符号相减
    
    // 前导零计数器（CLZ）用于规格化
    wire [4:0] clz;  // 用于存储前导零的数量
    assign clz = count_leading_zeros(mant_sum[23+5:0]);  // 计算前导零

    // 规格化（左移尾数，并调整指数）
    wire [23+5:0] mant_final = mant_sum[23+5:0] << clz;
    wire [7:0] exp_final = exp_result - clz;


    wire Guard = mant_final[5];
    wire Round = mant_final[4];
    wire Sticky = |mant_final[3:0];
    wire finalRound = Round&(Guard | Sticky);
    // 特殊情况处理（如尾数为零时）
    /*
    wire zero_case = (mant_sum[23:0] == 0);
    wire [7:0] exp_final_adjusted = zero_case ? 8'b0 : exp_final;
    wire [22:0] mant_final_adjusted = zero_case ? 23'b0 : mant_final[22:0];
    */
    // 重新组合结果
    wire [22:0] mant_final_final = (mant_final >> 5) + finalRound;
    assign result = {sign_a, exp_final, mant_final_final};

    // 前导零计数器模块
    function automatic [4:0] count_leading_zeros;
        input [23+5:0] value;
        integer i;
        begin
            count_leading_zeros = 0;
            for (i = 23+5; i >= 0; i = i - 1) begin
                if (value[i] == 1'b0)
                    count_leading_zeros = count_leading_zeros + 1;
                else
                    break;
            end
        end
    endfunction
endmodule

/*

module ieee754_add_sub(
    input [31:0] a,        // 输入浮点数A
    input [31:0] b,        // 输入浮点数B
    input add_sub,         // 加法（1）或减法（0）选择信号
    output [31:0] result   // 输出结果
);
    // 提取符号位、指数位和尾数位
    wire sign_a = a[31];
    wire sign_b = b[31] ^ (!add_sub);  // 如果是减法，反转符号位
    wire [7:0] exp_a = a[30:23];
    wire [7:0] exp_b = b[30:23];
    wire [23:0] mant_a = {1'b1, a[22:0]};  // 加入隐含1
    wire [23:0] mant_b = {1'b1, b[22:0]};  // 加入隐含1

    // 对齐指数
    wire [7:0] exp_diff = (exp_a >= exp_b) ? (exp_a - exp_b) : (exp_b - exp_a);
    wire [23:0] mant_a_shifted = (exp_a >= exp_b) ? mant_a : (mant_a >> exp_diff);
    wire [23:0] mant_b_shifted = (exp_a >= exp_b) ? (mant_b >> exp_diff) : mant_b;
    wire [7:0] exp_result = (exp_a >= exp_b) ? exp_a : exp_b;

    // 处理尾数加法/减法
    wire [24:0] mant_sum;
    assign mant_sum = (sign_a == sign_b) ?
                        (mant_a_shifted + mant_b_shifted) :  // 同符号直接相加
                        (mant_a_shifted > mant_b_shifted) ? 
                            (mant_a_shifted - mant_b_shifted) : 
                            (mant_b_shifted - mant_a_shifted);  // 异符号相减
    
    // 前导零计数器（CLZ）用于规格化
    wire [4:0] clz;  // 用于存储前导零的数量
    assign clz = count_leading_zeros(mant_sum[23:0]);  // 计算前导零

    // 规格化（左移尾数，并调整指数）
    wire [23:0] mant_final = mant_sum[23:0] << clz;
    wire [7:0] exp_final = exp_result - clz;

    // 特殊情况处理（如尾数为零时）
    wire zero_case = (mant_sum[23:0] == 0);
    wire [7:0] exp_final_adjusted = zero_case ? 8'b0 : exp_final;
    wire [22:0] mant_final_adjusted = zero_case ? 23'b0 : mant_final[22:0];

    // 重新组合结果
    assign result = {sign_a, exp_final_adjusted, mant_final_adjusted};

    // 前导零计数器模块
    function [4:0] count_leading_zeros;
        input [23:0] value;
        integer i;
        begin
            count_leading_zeros = 0;
            for (i = 23; i >= 0; i = i - 1) begin
                if (value[i] == 1'b0)
                    count_leading_zeros = count_leading_zeros + 1;
                else
                    break;
            end
        end
    endfunction
endmodule

*/