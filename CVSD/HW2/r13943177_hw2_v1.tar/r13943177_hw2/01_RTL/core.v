
`include "pc.v"
`include "alu.v"
`include "reg_file.v"
`include "control_unit.v" 
`include "ieee754_add_sub.v"
//`include "../00_TB/define.v"
module core #( // DO NOT MODIFY INTERFACE!!!
    parameter DATA_WIDTH = 32,
    parameter ADDR_WIDTH = 32
) ( 
    input i_clk,
    input i_rst_n,

    // Testbench IOs
    output [2:0] o_status, 
    output       o_status_valid,

    // Memory IOs
    output [ADDR_WIDTH-1:0] o_addr,
    output [DATA_WIDTH-1:0] o_wdata,
    output                  o_we,
    input  [DATA_WIDTH-1:0] i_rdata
);
localparam  IF   = 2'd0;
localparam  ID   = 2'd1;
localparam  WB   = 2'd2;
localparam  GENERATION = 2'd3;
// ---------------------------------------------------------------------------
// Wires and Registers
// ---------------------------------------------------------------------------
// ---- Add your own wires and registers here if needed ---- //


reg [2:0] status_o; 
reg       status_valid_o;
reg [ADDR_WIDTH-1:0] addr_o;
reg [DATA_WIDTH-1:0] wdata_o;
reg                  we_o;

    
reg [1:0] current_state, next_state;

wire [31:0] imm;
wire branch_taken;
wire counterEn;
wire [31:0] current_pc; 
wire pc_incvlaid;

reg [31:0] data1  ;
reg [31:0] data2  ;
wire [6:0]funct7 ;
wire [2:0]funct3 ;
wire [31:0] alu_result ;
wire  alu_overflow ; 

wire we_int ;
wire [4:0]r1_addr ;
wire [4:0]r2_addr ;
wire [4:0]rd_addr ;
reg  [31:0]rd_data ;
wire [31:0] r1_data_int ;
wire [31:0] r2_data_int ;

wire we_fl ;
wire [31:0]r1_data_fl ;
wire [31:0]r2_data_fl ;

reg [31:0] inst ;// 當前指令
wire  A_mux;
wire [1:0] B_mux;
wire [2:0] status;
reg  [2:0] finalStatus;
wire memRead;
wire memWrite;
wire r_type;
wire [6:0] opcode;
wire checkAddr;
wire invalid;
assign opcode = inst[6:0];
// ---------------------------------------------------------------------------
// Continuous Assignment
// ---------------------------------------------------------------------------
// ---- Add your own wire data assignments here if needed ---- //
assign counterEn = (current_state == GENERATION);

assign o_status = finalStatus;
assign invalid = checkAddr && ($signed(alu_result) < 32'sd4096 || $signed(alu_result) > 32'sd8192);
always@(*)begin
    if(alu_overflow || invalid)begin
        finalStatus = 3'd4;
    end
    else begin
        finalStatus = status;
    end
end
/*
assign o_status_valid = status_valid_o;
assign o_addr = addr_o;
assign o_wdata = wdata_o;
assign o_we = we_o;
*/

assign o_status_valid = status_valid_o;
assign o_addr = addr_o;
assign o_wdata = wdata_o;
assign o_we = (!invalid)?(we_o):(1'b0);

pc pc(
    .i_clk(i_clk),
    .i_reset(i_rst_n),
    .imm(imm),           
    .branch_taken(branch_taken), 
    .counterEn(counterEn),
    .o_pc(current_pc),           
    .o_pc_incvlaid(pc_incvlaid)
);

always@(*)begin
    data1 = (!A_mux)?(r1_data_int):(r1_data_fl);
    case(B_mux)
        2'd0:data2 = r2_data_int;
        2'd1:data2 = r2_data_fl;
        2'd2:data2 = imm;
        default:data2 = r2_data_int;
    endcase
end

always@(*)begin
    if(memRead)rd_data = i_rdata;
    else       rd_data = alu_result;
end

alu alu(
    .i_data1(data1),    // ALU 操作數1
    .i_data2(data2),    // ALU 操作數2 (可能是立即數或寄存器值)
    .r_type(r_type),
    .i_funct7(funct7),    // 功能碼，用於控制操作
    .i_funct3(funct3),    // 功能碼，用於控制操作
    .o_result(alu_result),    // ALU 輸出結果
    .o_overflow(alu_overflow),
    .floating(floating)
);

reg_file rf_int (
    .clk(i_clk),
    .i_rst_n(i_rst_n),
    .we(we_int && (current_state == GENERATION)),                   // 寫入使能信號
    .r1_addr(r1_addr),        // 來源暫存器 1 地址
    .r2_addr(r2_addr),        // 來源暫存器 2 地址
    .rd_addr(rd_addr),        // 目標暫存器地址
    .rd_data(rd_data),       // 要寫入的數據
    .r1_data(r1_data_int),      // 暫存器 1 讀取數據
    .r2_data(r2_data_int)       // 暫存器 2 讀取數據
);

reg_file rf_fl (
    .clk(i_clk),
    .i_rst_n(i_rst_n),
    .we(we_fl && (current_state == GENERATION)),                   // 寫入使能信號
    .r1_addr(r1_addr),        // 來源暫存器 1 地址
    .r2_addr(r2_addr),        // 來源暫存器 2 地址
    .rd_addr(rd_addr),        // 目標暫存器地址
    .rd_data(rd_data),       // 要寫入的數據
    .r1_data(r1_data_fl),      // 暫存器 1 讀取數據
    .r2_data(r2_data_fl)       // 暫存器 2 讀取數據
);


control_unit control_unit(
    .i_inst(inst),      // 當前指令
    .r1_data(r1_data_int),     // 寄存器 r1 的數據
    .r2_data(r2_data_int),     // 寄存器 r2 的數據
    .r1(r1_addr),           // 來源暫存器1
    .r2(r2_addr),           // 來源暫存器2
    .rd(rd_addr),           // 目標暫存器
    .imm(imm),         // 立即數
    .funct7(funct7),       // 功能碼 (R-type 指令用)
    .funct3(funct3),       // 功能碼 (B-type, R-type用)    
    .reg_we_i(we_int),             // 暫存器寫入使能信號
    .reg_we_f(we_fl),             // 暫存器寫入使能信號
    .branch_taken(branch_taken),        // 分支是否被採取
    .o_status(status),
    .A_mux(A_mux),
    .B_mux(B_mux),
    .memRead(memRead),
    .memWrite(memWrite),
    .r_type(r_type),
    .checkAddr(checkAddr),
    .floating(floating)
);



// ---------------------------------------------------------------------------
// Combinational Blocks
// ---------------------------------------------------------------------------
// ---- Write your conbinational block design here ---- //

always@(posedge i_clk or negedge i_rst_n)begin
    if(!i_rst_n)inst <= 32'd0;
    //else        inst <= i_rdata;
    else if(current_state == ID)inst <= i_rdata;
end






// ---------------------------------------------------------------------------
// Sequential Block
// ---------------------------------------------------------------------------
// ---- Write your sequential block design here ---- //

always@(posedge i_clk or negedge i_rst_n)begin
    if(!i_rst_n)current_state <= IF;
    else        current_state <= next_state;
end

always@(*)begin
    case(current_state)
        IF:begin
            next_state = ID;
        end
        ID:begin
            next_state = WB;
        end
        WB:begin
            next_state = GENERATION;
        end
        GENERATION:begin
            next_state = IF;
        end
        default:next_state = ID;
    endcase
end

//assign o_status = status_o;

always@(*)begin
    case(current_state)
        IF:begin
            status_o = 0 ;
            status_valid_o =0 ;
            wdata_o = 0 ;
            addr_o = current_pc ;
            we_o = 0 ;
        end
        ID:begin
            status_o = 0 ;
            status_valid_o =0 ;
            wdata_o = 0 ;
            addr_o = current_pc ;
            we_o = 0 ;
        end
        WB:begin
            status_o = 0 ;
            status_valid_o =0 ;
            if(inst[6:0] == 7'b0100111)
                wdata_o =  r2_data_fl;
            else
                wdata_o =  r2_data_int;
            addr_o = alu_result ;
            we_o = memWrite ;
        end
        GENERATION:begin
            status_o = status ;//
            status_valid_o = 1 ;
            wdata_o = 0;
            addr_o = current_pc ;
            we_o = 0 ;
        end
        default:begin
            status_o = 0 ;//
            status_valid_o = 0 ;
            wdata_o = 0 ;
            addr_o = 0 ;
            we_o = 0 ;
        end
    endcase
end

endmodule