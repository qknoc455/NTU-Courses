module pc (
    input wire i_clk,
    input wire i_reset,
    input signed  [31:0] imm,           // 立即數
    input wire branch_taken,         // 
    input wire counterEn,
    output reg signed [31:0] o_pc,           // 輸出的 PC 值
    output wire       o_pc_incvlaid
);
    assign o_pc_incvlaid = ((o_pc + imm) < 32'sd0);

    always @(posedge i_clk or negedge i_reset) begin
        if (!i_reset) begin
            o_pc <= 32'b0;  // 重置 PC
        end 
        else if(counterEn)begin
            if (branch_taken) begin
                o_pc <= o_pc + imm;  // 如果分支被採取，跳轉到 pc + imm
            end
            else begin
                o_pc <= o_pc + 32'sd4;    // 否則執行下一條指令
            end
        end
        
    end

endmodule

