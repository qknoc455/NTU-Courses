module alu (
    input wire signed [31:0] i_data1,    // ALU 操作數1
    input wire signed [31:0] i_data2,    // ALU 操作數2 (可能是立即數或寄存器值)
    input              r_type,
    input wire [6:0] i_funct7,    // 功能碼，用於控制操作
    input wire [2:0] i_funct3,
    input floating,    // 功能碼，用於控制操作
    output reg [31:0] o_result,    // ALU 輸出結果
    output reg      o_overflow
   
);
//////////////////////////////////////// Floating-Point ADD (FADD) ////////////////////////////////////////
    reg op_reg;
   /* wire op;                    // add=0 , sub=1
    wire [31:0] FA, FB;         // 輸入的兩個32位浮點數
    wire  [31:0] FS;            // 輸出結果

    wire [31:0] FB_M;
    wire FA_S, FB_S, FS_S;       // 符號位
    wire [7:0] FA_E, FB_E, FS_E; // 指數位
    wire [22:0] FA_F, FB_F, FS_F;// 尾數部分
    wire [25:0] FA_F_ext, FB_F_ext;
    wire [25:0] FA_F_com, FB_F_com;
    wire [25:0] FS_F_cal, FS_F_com;
    wire [4:0] FS_shift_num;
    wire [7:0] Ex_diff;
    wire valid, zero;
    assign FA = i_data1 ;
    assign FB = i_data2 ;
    assign op = op_reg ;
    // 合併操作碼和 FB
    assign FB_M = {op^FB[31], FB[30:0]};

    // 輸入的符號位可能是正數或負數
    // 交換兩個輸入的值，確保 FA_E 大於 FB_E
    assign {FA_S, FA_E, FA_F} = (FA[30:23] > FB[30:23]) ? FA : FB_M;
    assign {FB_S, FB_E, FB_F} = (FA[30:23] > FB[30:23]) ? FB_M : FA;

    // 擴展尾數，帶符號位、進位位和隱藏位
    assign FA_F_ext = {3'b001, FA_F};
    assign FB_F_ext = {3'b001, FB_F};

    // 使用指數位的差異對齊尾數位
    assign Ex_diff = FA_E - FB_E;
    assign FB_F_sh = FB_F_ext >> Ex_diff;

    // 如果數字是負數，取補碼
    assign FA_F_com = (FA_S) ? ~FA_F_ext + 26'd1 : FA_F_ext;
    assign FB_F_com = (FB_S) ? ~FB_F_sh + 26'd1 : FB_F_sh;

    // 計算結果，如果結果是負數，取補碼
    assign FS_F_cal = FA_F_com + FB_F_com;
    assign FS_F_com = (FS_F_cal[25]) ? ~FS_F_cal + 26'd1 : FS_F_cal;

    // 規範化
    assign FS_S = FS_F_com[25];   // 符號位
    assign FS_E = (FS_F_com[24]) ? (FA_E + 8'd1) : FA_E - FS_shift_num;  // 指數位
    assign FS_F = (FS_F_com[24]) ? FS_F_com[23:1] : (FS_F_com[22:0] << (5'd23 - FS_shift_num)); // 尾數位

    // 檢測是否為零
    assign zero = !(valid | FS_F_com[24] | FS_F_com[25]);
    assign FS = (zero) ? 32'd0 : {FS_S, FS_E, FS_F};  // 如果是零，則返回 0，否則返回結果*/


    wire  [31:0] a;
    wire  [31:0] b;
    wire  [31:0] result ;
    reg add_sub;

ieee754_add_sub uut (
        .a(a),
        .b(b),
        .add_sub(add_sub),
        .result(result)
    );
assign a = i_data1; 
assign b = i_data2; 
assign add_sub = op_reg ;
////////////////////////////////////////  Round to Nearest Even ////////////////////////////////////////
/*function [31:0] Round_FS; // 返回 32 位元
    input [31:0] pre_round;
    reg Guard;
    reg Round;
    reg [18:0] Sticky;
    reg S;
    reg carry;

    begin
        // 取得 Guard, Round 和 Sticky 位元
        Guard = pre_round[20];  
        Round = pre_round[19];
        Sticky = pre_round[18:0];  
        
        // 確定 Sticky 位元
        S = (Sticky == 0) ? 0 : 1; 
        
        carry = 1'b0; // 初始化進位為 0
        
        // 根據 Guard, Round 和 Sticky 計算進位
        case({Guard, Round, S}) 
            3'b000: carry = 1'b0;
            3'b001: carry = 1'b0;
            3'b010: carry = 1'b0;
            3'b011: carry = 1'b1;
            3'b100: carry = 1'b0;
            3'b101: carry = 1'b0;
            3'b110: carry = 1'b1;
            3'b111: carry = 1'b1;
            default: carry = 1'b0; 
        endcase

        // 根據進位決定最終結果
        if(carry) begin
            Round_FS = {pre_round[31:20], 20'b00000_00000_00000_00000} + 21'b00000_00000_00000_00001; // 進位
        end else begin
            Round_FS = {pre_round[31:20], 20'b00000_00000_00000_00000}; // 無進位
        end
    end
endfunction*/



//////////////////////////////////////// Floating-Point Comparison (FLT) ////////////////////////////////////////
function automatic flt_compare;
    input [31:0] fa, fb;
    reg fa_s, fb_s;
    reg [7:0] fa_e, fb_e;
    reg [22:0] fa_f, fb_f;

    // 為了讓函數正確工作，應該設置輸出類型
    reg result; // 存儲比較結果
    begin
        fa_s = fa[31];  // 符號位
        fb_s = fb[31];
        fa_e = fa[30:23];  // 指數部分
        fb_e = fb[30:23];
        fa_f = fa[22:0];  // 尾數部分
        fb_f = fb[22:0];

        if (fa_s != fb_s) begin
            // 符號不同時，負數小於正數
            result = fa_s; // 輸出符號位
        end else begin
            if (fa_e != fb_e) begin
                // 指數不同時，指數小的數比較小
                result = (fa_s == 0) ? (fa_e < fb_e) : (fa_e > fb_e);
            end else begin
                // 指數相同時，比較尾數
                result = (fa_s == 0) ? (fa_f < fb_f) : (fa_f > fb_f);
            end
        end

        flt_compare = result; // 返回比較結果
    end
endfunction



//////////////////////////////////////// R-type ////////////////////////////////////////
    always @(*) begin
        o_overflow = 1'b0;
        o_result =0;
        op_reg = 1'b0;
        if(r_type == 1)begin
            case (i_funct3)
                3'b000: begin  // ADD 或 SUB
                    if (i_funct7 == 7'b0000000 && !floating) begin
                        o_result = i_data1 + i_data2; // ADD
                        
                        if ((i_data1[31] == i_data2[31]) && (o_result[31] != i_data1[31])) begin
                            o_overflow = 1'b1;
                            op_reg = 1'b0;
                        end
                    end 
                    else if (i_funct7 == 7'b0100000 && !floating) begin
                        o_result = i_data1 - i_data2; // SUB
                        
                        if ((i_data1[31] != i_data2[31]) && (o_result[31] != i_data1[31])) begin
                            o_overflow = 1'b1;
                            op_reg = 1'b0;
                        end
                    end
                    else if (i_funct7 == 7'b0000000 && floating ) begin
                          
                            op_reg = 1'b1;  // 設置為加法
                            o_result = result;//Round_FS(result);  // FADD  還沒做ROUND
                            if(i_data1[30:23] == 8'd255 || i_data2[30:23] == 8'd255)begin
                                o_overflow = 1'b1;
                               // $display("overFlow!!!!");
                            end
                            else 
                                o_overflow = 1'b0;
                    end
                    else if (i_funct7 == 7'b0000100 && floating) begin
                            
                            op_reg = 1'b0;  // 設置為減法
                            o_result = result;//Round_FS(result);  // FSUB
                            if(i_data1[30:23] == 8'd255 || i_data2[30:23] == 8'd255)
                                o_overflow = 1'b1;
                            else 
                                o_overflow = 1'b0;
                    end
                    else if (i_funct7 == 7'b1110000) begin
                            if(!i_data1[31] && (i_data1[30:23]==0)&&(i_data1[22:0]!=0))
                                o_result = 32'd5;
                            else if (i_data1[31] && (i_data1[30:23]==0)&&(i_data1[22:0]!=0))
                                o_result = 32'd2;
                            else if ((i_data1[30:23]==8'b11111111)&&(i_data1[22:0]!=0))
                                    o_result =32'd8;
                            else if (i_data1[31] && (i_data1[30:23]!=0))
                                 o_result = 32'd1;
                            else if (!i_data1[31] && (i_data1[30:23]!=0))
                                 o_result = 32'd6;
                            else
                                case(i_data1)
                                   32'b1_11111111_00000000000000000000000: o_result = 32'd0;
                                   32'b1_00000000_00000000000000000000000: o_result = 32'd3;
                                   32'b0_00000000_00000000000000000000000: o_result = 32'd4;
                                   32'b0_11111111_00000000000000000000000: o_result = 32'd7;
                                   default:o_result =32'd8;
                        endcase
                    end
                    
                end

                3'b001: begin 
                    if (i_funct7 == 7'b0000000) begin
                        o_result = $unsigned(i_data1) << $unsigned(i_data2);      // SL
                        op_reg = 1'b0;
                    end 
                    else if (i_funct7 == 7'b1010000) begin // FLT
                        o_result = (flt_compare(i_data1, i_data2)) ? 32'd1 : 32'd0;
                    end  
                end

                3'b010: begin  // SLT 
                    o_result = (i_data1 < i_data2) ? 1 : 0; 
                    op_reg = 1'b0; 
                end

                3'b101: begin  // SRL 右移
                    o_result = i_data1 >> i_data2; 
                    op_reg = 1'b0; 
                end

            
                default: begin
                    o_result = 32'b0;  // 無效操作
                    op_reg = 1'b0;
                end
            endcase
        end
        else begin
            o_result = i_data1 + i_data2; // ADD
            if ((i_data1[31] == i_data2[31]) && (o_result[31] != i_data1[31])) begin
                o_overflow = 1'b1;
                op_reg = 1'b0;
               
            end
        end
    end
endmodule