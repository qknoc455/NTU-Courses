module control_unit (
    input wire [31:0] i_inst,      // 當前指令
    input wire [31:0] r1_data,     // 寄存器 r1 的數據
    input wire [31:0] r2_data,     // 寄存器 r2 的數據
    output reg [4:0] r1,           // 來源暫存器1
    output reg [4:0] r2,           // 來源暫存器2
    output reg [4:0] rd,           // 目標暫存器
    output reg [31:0] imm,         // 立即數
    output reg [6:0] funct7,       // 功能碼 (R-type 指令用)
    output reg [2:0] funct3,       // 功能碼 (B-type, R-type用)    
    output reg reg_we_i,             // 暫存器寫入使能信號
    output reg reg_we_f,             // 暫存器寫入使能信號
    output reg branch_taken,        // 分支是否被採取
    output reg [2:0] o_status,
    output reg  A_mux,
    output reg [1:0] B_mux,
    output reg memRead,
    output reg memWrite,
    output reg r_type,
    output reg checkAddr,
    output reg floating
);


    // OP_ADD    7'b0110011
    // OP_SUB    7'b0110011
    // OP_ADDI   7'b0010011
    // OP_LW     7'b0000011
    // OP_SW     7'b0100011
    // OP_BEQ    7'b1100011
    // OP_BLT    7'b1100011
    // OP_SLT    7'b0110011
    // OP_SLL    7'b0110011
    // OP_SRL    7'b0110011
    // OP_FADD   7'b1010011 //write float rf
    // OP_FSUB   7'b1010011 //write float rf
    // OP_FLW    7'b0000111 
    // OP_FSW    7'b0100111
    // OP_FCLASS 7'b1010011 //write int rf
    // OP_FLT    7'b1010011 //write int rf
    // OP_EOF    7'b1110011

// FUNCT7_FCLASS 7'b1110000
// FUNCT7_FLT    7'b1010000

// FUNCT7_ADD    7'b0000000
// FUNCT7_SUB    7'b0100000

    
    wire [6:0] opcode = i_inst[6:0];  // 取操作碼
    always @(*) begin
        branch_taken = 0;   // 預設分支不被採取
        memRead = 0;
        memWrite = 0;
        checkAddr = 0;
        floating =0;
        r2 = 0 ;
        rd = 0;
        r_type = 0 ;
        case (opcode)
            7'b0110011: begin  // R-type
                r1    = i_inst[19:15];  // 來源暫存器1
                r2    = i_inst[24:20];  // 來源暫存器2
                rd     = i_inst[11:7];   // 目標暫存器
                funct7 = i_inst[31:25];  // 功能碼
                funct3 = i_inst[14:12];  // 功能碼
                reg_we_i = 1;  // 啟動寫入暫存器 a_bar | a & b = a_bar | b
                reg_we_f = 0;
                A_mux = 0 ;
                B_mux = 0 ;
                r_type = 1;
                o_status = 3'd0;
                imm = 0 ;
                floating =1'b0;
                           
            end

            7'b1010011: begin  // floating
                r1    = i_inst[19:15];  // 來源暫存器1
                r2    = i_inst[24:20];  // 來源暫存器2
                rd     = i_inst[11:7];   // 目標暫存器
                funct7 = i_inst[31:25];  // 功能碼
                funct3 = i_inst[14:12];  // 功能碼
                reg_we_i = funct7[6];  // 啟動寫入暫存器 a_bar | a & b = a_bar | b
                reg_we_f = !funct7[6];
                A_mux = 1 ;
                B_mux = 1 ;
                r_type = 1;
                o_status = 3'd0;
                imm = 0 ;
                floating =1'b1;
                           
            end


            7'b0010011: begin  // I-type
                r1    = i_inst[19:15];  // 來源暫存器1
                r2 = 0 ;
                funct7 = i_inst[31:25];  // 功能碼
                funct3 = i_inst[14:12];  // 功能碼
                rd     = i_inst[11:7];   // 目標暫存器
                imm    = {{20{i_inst[31]}}, i_inst[31:20]}; // 擴展立即數
                reg_we_i = 1;  
                reg_we_f = 0; 
                A_mux = 0 ;
                B_mux = 2 ;          // 啟動寫入暫存器
                r_type = 0 ;
                o_status = 3'd1;           
            end

            7'b0100011,7'b0100111: begin  // S-type
                r1    = i_inst[19:15];  // 來源暫存器1
                r2    = i_inst[24:20];  // 來源暫存器2
                rd = 0;
                funct7 = i_inst[31:25];  // 功能碼
                funct3 = i_inst[14:12];  // 功能碼
                imm    = {{20{i_inst[31]}}, i_inst[31:25], i_inst[11:7]};  // S-type 立即數
                reg_we_i = 0; 
                reg_we_f = 0;  
                A_mux = 0 ;
                B_mux = 2 ;            // 禁止寫入暫存器（因為是存儲指令）
                r_type = 0;     
                o_status = 3'd2;
                //imm = 0 ;
                memWrite = 1;
                checkAddr = 1;
            end

            7'b1100011: begin  // B-type (包括 beq 和 blt 指令)
                r1    = i_inst[19:15];  // 來源暫存器1
                r2    = i_inst[24:20];  // 來源暫存器2
                rd = 0;
                funct7 = i_inst[31:25];  // 功能碼
                funct3 = i_inst[14:12];  // 功能碼
                imm    = {{19{i_inst[31]}}, i_inst[31], i_inst[7], i_inst[30:25], i_inst[11:8], 1'b0};  // B-type 立即數
                reg_we_i = 0; 
                reg_we_f = 0;  
                A_mux = 0 ;
                B_mux = 0 ;            // 禁止寫入暫存器（因為是分支指令）
                r_type = 0;              
                o_status = 3'd3;
                if (i_inst[14:12] == 3'b000) begin  // beq 指令
                    if (r1_data == r2_data) begin
                        branch_taken = 1;           // 當 $r1 == $r2，分支被採取
                    end
                end
                else if (i_inst[14:12] == 3'b100) begin  // blt 指令
                    if ($signed(r1_data) < $signed(r2_data)) begin
                        branch_taken = 1;           // 當 $r1 < $r2，分支被採取
                    end
                end
            end

            7'b0000011,7'b0000111: begin  // I-type
                funct7 = i_inst[31:25];  // 功能碼
                funct3 = i_inst[14:12];  // 功能碼
                r1    = i_inst[19:15];  // 來源暫存器1
                r2 = 0 ;
                rd     = i_inst[11:7];   // 目標暫存器
                imm    = {{20{i_inst[31]}}, i_inst[31:20]}; // 擴展立即數
                reg_we_i = !opcode[2];              // 啟動寫入暫存器
                reg_we_f = opcode[2];  
                A_mux = 0 ;
                B_mux = 2 ;            // 啟動寫入暫存器
                r_type = 0 ;
                o_status = 3'd1;   
                memRead = 1;
                checkAddr = 1;         
            end

            7'b1110011:begin  // 無效指令
                r1 = 0 ;
                r2 = 0 ;
                rd = 0;
                imm = 0 ;
                reg_we_i = 0;
                reg_we_f = 0;
                A_mux = 0 ;
                B_mux = 0 ;
                branch_taken = 0;
                o_status = 3'd5;
                funct7 = 0;  // 功能碼
                funct3 = 0;  // 功能碼
                r_type = 0 ;
            end

            default: begin  // 無效指令
                r1 = 0 ;
                r2 = 0 ;
                rd = 0;
                imm = 0 ;
                reg_we_i = 0;
                reg_we_f = 0;
                A_mux = 0 ;
                B_mux = 0 ;
                branch_taken = 0;
                o_status = 3'd0;
                memRead = 0;
                memWrite = 0;
                r_type = 0;
                funct7 = 0;  // 功能碼
                funct3 = 0;  // 功能碼
            end
        endcase
    end

endmodule

