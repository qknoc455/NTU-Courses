module reg_file (
    input wire clk,
    input wire i_rst_n,
    input wire we,                   // 寫入使能信號
    input wire [4:0] r1_addr,        // 來源暫存器 1 地址
    input wire [4:0] r2_addr,        // 來源暫存器 2 地址
    input wire [4:0] rd_addr,        // 目標暫存器地址
    input wire [31:0] rd_data,       // 要寫入的數據
    output wire [31:0] r1_data,      // 暫存器 1 讀取數據
    output wire [31:0] r2_data       // 暫存器 2 讀取數據
);

    // 32 個 32-bit 暫存器
    reg [31:0] reg_file [0:31];
    integer i;
    // 讀取操作
    assign r1_data = reg_file[r1_addr];  // 讀取來源暫存器 1
    assign r2_data = reg_file[r2_addr];  // 讀取來源暫存器 2

    // 寫入操作（在正緣時鐘下執行）
    always @(posedge clk or negedge i_rst_n ) begin
        if(!i_rst_n)begin
            for (i = 0; i < 32; i = i + 1) 
                reg_file[i] <= 32'b0;
        end
        else if (we) begin  // we 為 1 時寫入，並避免寫入到 $zero 暫存器
            reg_file[rd_addr] <= rd_data;
        end
    end

endmodule
